Contemporary ONE Font 

Yuliyan Ilev (c) 2010. All Rights Reserved.
..............................................


Thank you for downloading the Contemporary Font!


Licence:

You are allowed to use this font for private and non-commercial purpose.

Commercial Licence:

3,50 EUR

via PayPal to milabrya@yahoo.de

 
milabrya@yahoo.de